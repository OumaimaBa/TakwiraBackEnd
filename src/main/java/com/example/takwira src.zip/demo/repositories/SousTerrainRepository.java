package com.example.demo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.entities.SousTerrain;
import com.example.demo.entities.SousTerrainId;
public interface SousTerrainRepository extends JpaRepository<SousTerrain,SousTerrainId>{

}
