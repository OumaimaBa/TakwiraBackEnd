package com.example.demo.entities;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Reservation {
	
	@EmbeddedId
	private ReservationId rid;

	@ManyToOne
	@JoinColumn(name = "username",insertable = false, updatable = false)
	private Utilisateur user;
	
	public Utilisateur getUser() {
		return user;
	}

	public void setUser(Utilisateur user) {
		this.user = user;
	}

	public Reservation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Reservation(ReservationId r_id, Utilisateur user) {
		super();
		rid = r_id;
		this.user = user;
	}

	public ReservationId getR_id() {
		return rid;
	}

	public void setR_id(ReservationId r_id) {
		rid = r_id;
	}
	
}

