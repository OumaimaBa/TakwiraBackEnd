package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.Image;

public interface ImageService {

	public Image getImageById(Long id);
	public Image getImageByTerrain(Long id);
	public Image addImage(Image i);
	public List<Image> getAllImages();
}
