package com.example.demo.services;

import java.util.List;


import com.example.demo.entities.Terrain;

public interface TerrainService {

	public Terrain getTerrainById(String id);
	public Terrain addTerrain(Terrain t);
	public List<Terrain> getAllTerrains();	
}
