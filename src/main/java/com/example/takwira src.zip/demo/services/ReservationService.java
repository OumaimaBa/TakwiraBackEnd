package com.example.demo.services;

import java.util.List;

import com.example.demo.entities.Reservation;
import com.example.demo.entities.ReservationId;

public interface ReservationService {

	List<Reservation> getAllReservations();

	void deleteReservation(ReservationId id);

	Reservation saveReservation(Reservation reservation);

	Reservation getReservationById(ReservationId id);

}
