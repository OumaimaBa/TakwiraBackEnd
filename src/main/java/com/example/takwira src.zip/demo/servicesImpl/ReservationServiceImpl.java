package com.example.demo.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Reservation;
import com.example.demo.entities.ReservationId;
import com.example.demo.repositories.ReservationRepository;
import com.example.demo.services.ReservationService;

@Service
public class ReservationServiceImpl implements ReservationService{

	@Autowired
    private ReservationRepository reservationRepository;

	@Override
	public Reservation saveReservation(Reservation reservation) {
		ReservationId r = new ReservationId(reservation.getR_id().getSousTerrain(),reservation.getR_id().getDate(),reservation.getR_id().getTime());
		if(reservationRepository.findByRid(r).size()!=0) {
	        throw new RuntimeException("Terrain non disponible ");
	    }
	    return reservationRepository.save(reservation);
	}

	@Override
    public void deleteReservation(ReservationId id) {
        reservationRepository.deleteById(id);
    }

	@Override
	public List<Reservation> getAllReservations() {
		return reservationRepository.findAll();
	}

	@Override
	public Reservation getReservationById(ReservationId id) {
		// TODO Auto-generated method stub
		return null;
	}
}
