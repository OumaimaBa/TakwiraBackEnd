package com.example.demo.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Image;
import com.example.demo.repositories.ImageRepository;
import com.example.demo.services.ImageService;

@Service
public class ImageServiceImpl implements ImageService{
	
	@Autowired
	public ImageRepository imageRepo;
	
	@Override
	public Image getImageById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Image getImageByTerrain(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	
	@Override
	public List<Image> getAllImages() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Image addImage(Image i) {
		// TODO Auto-generated method stub
		return imageRepo.save(i);
	}

}
