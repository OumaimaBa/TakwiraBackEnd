package com.example.demo.servicesImpl;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.demo.entities.Image;
import com.example.demo.entities.SousTerrain;
import com.example.demo.entities.SousTerrainId;
import com.example.demo.entities.Terrain;
import com.example.demo.repositories.ImageRepository;
import com.example.demo.repositories.SousTerrainRepository;
import com.example.demo.repositories.TerrainRepository;
import com.example.demo.services.TerrainService;

@Service
public class TerrainServiceImpl implements TerrainService{

	@Autowired
	private TerrainRepository terrainRepo;
	@Autowired
	private SousTerrainRepository STRepo;
	@Autowired
    private BCryptPasswordEncoder passwordEncoder;
	
	@Override
	public List<Terrain> getAllTerrains() {
		// TODO Auto-generated method stub
		return terrainRepo.findAll();
	}

	@Override
	public Terrain getTerrainById(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Terrain addTerrain(Terrain terrain) {
		String encodedPassword = passwordEncoder.encode(terrain.getMdp());
        terrain.setMdp(encodedPassword);
	    Terrain terrainAjoute = terrainRepo.save(terrain);
	    for (SousTerrain sousTerrain : terrain.getSousTerrains()) {
	        SousTerrainId sousTerrainId = new SousTerrainId(sousTerrain.getIdST().getNom(), terrain);
	        sousTerrain.setIdST(sousTerrainId);
	        STRepo.save(sousTerrain);
	    }
	    return terrainAjoute;
	}

}
