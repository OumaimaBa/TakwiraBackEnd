package com.example.demo.controllers;

import java.io.IOException;
import java.util.Optional;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.demo.entities.Image;
import com.example.demo.entities.Terrain;
import com.example.demo.repositories.TerrainRepository;
import com.example.demo.services.ImageService;

@CrossOrigin("*")
@RequestMapping("images")
@RestController
public class ImageController {
	
	@Autowired
	public ImageService imageService;
	@Autowired
	public TerrainRepository TRepo;
	
	@PostMapping("/add")
	public ResponseEntity<String> createImage(@RequestParam("file") @NotNull MultipartFile file, @RequestParam String terrainId) {
	    try {
	        byte[] bytes = file.getBytes();
	        
	        Optional<Terrain> terrain = TRepo.findById(terrainId);
	        if (terrain == null) {
	            return new ResponseEntity<>("Terrain introuvable", HttpStatus.NOT_FOUND);
	        }
	        
	        Image image = new Image();
	        image.setBin(bytes);
	        image.setTerrain(terrain.get());
	        
	        imageService.addImage(image);
	        
	        return new ResponseEntity<>("L'image a été ajoutée avec succès", HttpStatus.OK);
	    } catch (IOException e) {
	        return new ResponseEntity<>("Erreur lors de la lecture du fichier", HttpStatus.BAD_REQUEST);
	    }
	}



}
