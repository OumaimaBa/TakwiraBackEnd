package com.example.demo.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entities.Terrain;
import com.example.demo.services.TerrainService;

@CrossOrigin("*")
@RequestMapping("terrains")
@RestController
public class TerrainController {
	
	@Autowired
	public TerrainService terrainService;
	
	@GetMapping
	public List<Terrain> getAllTerrains(){
		return terrainService.getAllTerrains();
	}
	
	@PostMapping("/add")
	public Terrain addTerrain(@RequestBody Terrain t) {
		return terrainService.addTerrain(t);
	}
	
	@GetMapping("/{id}")
	public Terrain getTerrainById(@PathVariable("id") String id) {
		return terrainService.getTerrainById(id);
	}

}
